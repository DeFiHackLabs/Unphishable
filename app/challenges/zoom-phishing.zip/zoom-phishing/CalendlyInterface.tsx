import React, { useState } from "react";

interface CalendlyInterfaceProps {
  onComplete: () => void;
}

export default function CalendlyInterface({ onComplete }: CalendlyInterfaceProps) {
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedTime, setSelectedTime] = useState("");
  const [step, setStep] = useState(1);
  
  const dates = ["2023-11-20", "2023-11-21", "2023-11-22", "2023-11-23", "2023-11-24"];
  const times = ["09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"];
  
  const handleDateSelect = (date: string) => {
    setSelectedDate(date);
    setStep(2);
  };
  
  const handleTimeSelect = (time: string) => {
    setSelectedTime(time);
    setStep(3);
  };
  
  const handleConfirm = () => {
    setTimeout(() => {
      onComplete();
    }, 1000);
  };
  
  return (
    <div className="p-6">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-6">
          <h2 className="text-xl font-bold">Web3 技術面試預約</h2>
          <p className="text-gray-600">選擇一個適合您的時間，我們將通過 Zoom 進行面試</p>
        </div>
        
        <div className="flex justify-center mb-6">
          <div className="w-full max-w-md">
            {step === 1 && (
              <div>
                <h3 className="font-medium mb-3">選擇日期:</h3>
                <div className="grid grid-cols-5 gap-2">
                  {dates.map((date) => (
                    <button 
                      key={date}
                      className={`border p-2 rounded ${selectedDate === date ? 'bg-blue-500 text-white' : 'hover:bg-gray-100'}`}
                      onClick={() => handleDateSelect(date)}>
                      {new Date(date).toLocaleDateString('zh-TW', {month: 'short', day: 'numeric'})}
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {step === 2 && (
              <div>
                <h3 className="font-medium mb-3">選擇時間:</h3>
                <div className="grid grid-cols-4 gap-2">
                  {times.map((time) => (
                    <button 
                      key={time}
                      className={`border p-2 rounded ${selectedTime === time ? 'bg-blue-500 text-white' : 'hover:bg-gray-100'}`}
                      onClick={() => handleTimeSelect(time)}>
                      {time}
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {step === 3 && (
              <div className="text-center">
                <div className="mb-4 p-4 bg-gray-50 rounded">
                  <h3 className="font-bold mb-2">您已選擇的時間:</h3>
                  <p>{selectedDate} {selectedTime}</p>
                </div>
                <button 
                  onClick={handleConfirm}
                  className="bg-blue-500 text-white px-6 py-2 rounded">
                  確認預約
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
