import React, { useState, useEffect } from "react";
import { FaMicrophone, FaVideo, FaDesktop, FaUserFriends } from "react-icons/fa";
import MaliciousAlert from "./MaliciousAlert";

interface ZoomMeetingInterfaceProps {
  authorized: boolean;
}

const ZoomMeetingInterface: React.FC<ZoomMeetingInterfaceProps> = ({ authorized }) => {
  const [alertCompleted, setAlertCompleted] = useState(false);
  const [selectedLink, setSelectedLink] = useState("");
  const [zoomLoaded, setZoomLoaded] = useState(false);
  const [showLoginForm, setShowLoginForm] = useState(false);

  useEffect(() => {
    // 隨機選擇一個釣魚網址
    const phishingDomains = [
      "https://zoom.com/j/94567821337?pwd=a1BcD3efGHiJkLmN0pQrS",
      "https://usweb01.us/j/98765432100?pwd=Zoom2023SecureMeeting",
      "https://zoom.us/j/92837465019?pwd=XyZ1AbC2d3EfG4h5I6jK",
      "https://us40web.us/j/97531246800?pwd=BlockchainTalkToday"
    ];

    const randomIndex = Math.floor(Math.random() * phishingDomains.length);
    setSelectedLink(phishingDomains[randomIndex]);
  }, []);

  const handleAlertComplete = () => {
    setAlertCompleted(true);
  };

  const handleLinkClick = (e: React.MouseEvent) => {
    e.preventDefault();
    setShowLoginForm(true);
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowLoginForm(false);
    setZoomLoaded(true);
  };

  return (
    <div className="w-full h-[600px] bg-black relative">
      {!zoomLoaded ? (
        <div className="h-full w-full flex flex-col items-center justify-center bg-white">
          {!showLoginForm ? (
            <div className="max-w-md p-6 bg-white rounded-lg shadow-md border border-gray-200">
              <div className="flex items-center mb-4">
                <img src="https://st1.zoom.us/static/6.3.10815/image/favicon.png" alt="Zoom" className="w-8 h-8 mr-2" />
                <h2 className="text-xl font-bold text-gray-800">Zoom 會議</h2>
              </div>

              <div className="mb-4">
                <p className="text-sm mb-2">感謝您預約 Web3.0 人才面試。以下是您的會議資訊：</p>
                <div className="bg-gray-100 p-3 rounded text-sm font-mono break-all border border-gray-300">
                  <p className="mb-1"><span className="font-semibold">主題:</span> Web3.0 人才招募面試</p>
                  <p className="mb-1"><span className="font-semibold">時間:</span> 今天, 15:00-16:00</p>
                  <p><span className="font-semibold">連結:</span> <a href="#" onClick={handleLinkClick} className="text-blue-600 hover:underline">{selectedLink}</a></p>
                </div>
              </div>

              <div className="text-center">
                <p className="text-sm text-gray-600 mb-3">點擊上方連結加入會議</p>
                <button
                  onClick={handleLinkClick}
                  className="w-full bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded transition-colors">
                  加入會議
                </button>
              </div>
            </div>
          ) : (
            <div className="max-w-md p-6 bg-white rounded-lg shadow-md border border-gray-200">
              <div className="flex items-center mb-4">
                <img src="https://st1.zoom.us/static/6.3.10815/image/favicon.png" alt="Zoom" className="w-8 h-8 mr-2" />
                <h2 className="text-xl font-bold text-gray-800">加入 Zoom 會議</h2>
              </div>

              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">電子郵件</label>
                  <input type="email" className="w-full px-3 py-2 border border-gray-300 rounded-md" placeholder="name@example.com" required />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">密碼</label>
                  <input type="password" className="w-full px-3 py-2 border border-gray-300 rounded-md" placeholder="••••••••" required />
                </div>
                <div className="flex items-center">
                  <input type="checkbox" id="remember" className="mr-2" />
                  <label htmlFor="remember" className="text-sm text-gray-600">記住我</label>
                </div>
                <button type="submit" className="w-full bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded transition-colors">
                  登入並加入
                </button>
              </form>
            </div>
          )}
        </div>
      ) : (
        <>
          {/* 視訊畫面 */}
          <div className="grid grid-cols-2 gap-2 p-4 h-[500px]">
            <div className="bg-gray-800 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <div className="w-24 h-24 bg-blue-500 rounded-full mx-auto flex items-center justify-center text-white text-2xl font-bold">
                  AC
                </div>
                <p className="text-white mt-2">Aureon Capital (主持人)</p>
              </div>
            </div>
            <div className="bg-gray-800 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <div className="w-24 h-24 bg-green-500 rounded-full mx-auto flex items-center justify-center text-white text-2xl font-bold">
                  您
                </div>
                <p className="text-white mt-2">您 (受邀嘉賓)</p>
              </div>
            </div>
          </div>

          {/* 聊天內容 */}
          <div className="absolute right-4 top-4 w-64 bg-gray-900 rounded-lg p-3 border border-gray-700 shadow-lg opacity-80">
            <div className="text-sm text-gray-300 mb-2">
              <span className="font-bold text-blue-400">Aureon Capital:</span> 感謝您參加我們的 podcast 節目！
            </div>
            <div className="text-sm text-gray-300 mb-2">
              <span className="font-bold text-blue-400">Aureon Capital:</span> 請問可以和我們分享一下您的螢幕嗎？想看看您最近的專案。
            </div>
            <div className="text-sm text-gray-300">
              <span className="font-bold text-green-400">您:</span> 好的，我現在就分享。
            </div>
          </div>

          {/* 授權後的惡意警報 */}
          {authorized && !alertCompleted && (
            <MaliciousAlert onComplete={handleAlertComplete} />
          )}

          {/* Zoom 控制列 */}
          <div className="absolute bottom-0 left-0 right-0 bg-gray-900 p-3 flex justify-center space-x-4">
            <button className="p-3 bg-gray-800 rounded-lg text-white hover:bg-gray-700">
              <FaMicrophone />
            </button>
            <button className="p-3 bg-gray-800 rounded-lg text-white hover:bg-gray-700">
              <FaVideo />
            </button>
            <button className="p-3 bg-gray-800 rounded-lg text-white hover:bg-gray-700">
              <FaDesktop />
            </button>
            <button className="p-3 bg-gray-800 rounded-lg text-white hover:bg-gray-700">
              <FaUserFriends />
            </button>
            <button className="px-4 py-2 bg-red-600 rounded-lg text-white font-medium hover:bg-red-700">
              結束會議
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default ZoomMeetingInterface;
